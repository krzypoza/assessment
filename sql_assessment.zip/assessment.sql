set echo on
spool %UserProfile%\Desktop\kpozarski_log.txt


/*      Task 1 from NCDC SQL & PLSQL assessment

	          Create table Documents				*/

CREATE TABLE documents (
    Document_id NUMBER CONSTRAINT document_id_pk PRIMARY KEY,
    Document_name VARCHAR2(50) NOT NULL,
    Document_description VARCHAR2(4000),
    Record_Timestamp TIMESTAMP NOT NULL,
    timestamp TIMESTAMP NOT NULL,
    Record_user_id VARCHAR2(50) NOT NULL,
    User_id VARCHAR2(50) NOT NULL);
	
/* Create a sequence dokument_id, it will be using to insert document_id */

CREATE SEQUENCE seq_document_id NOCACHE;

/* Create a trigger it will check inserting time before update record_timestamp */

CREATE OR REPLACE TRIGGER tr_Record_timestamp
BEFORE UPDATE ON Documents
FOR EACH ROW 
	WHEN (new.record_timestamp <> old.record_timestamp)
BEGIN														
    :new.record_timestamp := :old.record_timestamp;
END;
/

/* Create a trigger it will check inserting user before update record_user_id */

CREATE OR REPLACE TRIGGER tr_record_user_id
BEFORE UPDATE ON Documents
FOR EACH ROW 
	WHEN (old.record_user_id IS NOT NULL)
BEGIN													
    :new.record_user_id := :old.record_user_id;
END;
/

/* Create a trigger it will insert dokument_id from sequence */

CREATE OR REPLACE TRIGGER tr_document_id
BEFORE INSERT OR UPDATE ON Documents
FOR EACH ROW
BEGIN
    :new.document_id := seq_document_id.nextval;
END;
/

/* Task 2 from NCDC SQL & PLSQL assessment
	Create package pg_documents */
	
CREATE OR REPLACE PACKAGE pg_documents IS
    FUNCTION proc_pesel(pesel INTEGER) RETURN BOOLEAN;
    PROCEDURE print_documents;
END;
/


CREATE OR REPLACE PACKAGE BODY pg_documents IS
    
/* function validate pesel control digit */
		
		FUNCTION proc_pesel(pesel INTEGER) 
    RETURN BOOLEAN IS
    ver CHAR(1);
    exc_pesel EXCEPTION;
    BEGIN     
     ver  := MOD  ((SUBSTR(pesel, 1, 1)* 9 +
                    SUBSTR(pesel, 2, 1)* 7 +
                    SUBSTR(pesel, 3, 1)* 3 +
                    SUBSTR(pesel, 4, 1)* 1 +
                    SUBSTR(pesel, 5, 1)* 9 +
                    SUBSTR(pesel, 6, 1)* 7 +
                    SUBSTR(pesel, 7, 1)* 3 +
                    SUBSTR(pesel, 8, 1)* 1 +
                    SUBSTR(pesel, 9, 1)* 9 +
                    SUBSTR(pesel, 10, 1)* 7),10);
     IF LENGTH(pesel) <> 11 
     THEN RAISE exc_pesel;
     ELSIF ver = SUBSTR(pesel, 11, 1)
        THEN RETURN true;
        ELSE RETURN false;
        END IF;
    EXCEPTION
    WHEN exc_pesel THEN RAISE_APPLICATION_ERROR('-20001','INCORRECT PESEL LENGTH, SHOULD HAVE 11 CHARACTERS');
END;
 
/* procedure print document description */
 
    PROCEDURE print_documents IS
    CURSOR k IS
        (SELECT document_description AS description, document_name AS name FROM documents);
    BEGIN
        FOR x IN k LOOP
            IF x.description IS NOT NULL
            THEN dbms_output.put_line(x.name);
            ELSE dbms_output.put_line('No Description');
            END IF;
        END LOOP;
    END;
END;
/

/* Task 4 from NCDC SQL & PLSQL assessment

 procedure read data from csv file and inserting to a table */

CREATE OR REPLACE PROCEDURE ins_csv(directory_name VARCHAR2, csv_file VARCHAR2) IS
    DOC_FILE UTL_FILE.FILE_TYPE;
    LINIA VARCHAR2(4500);
    P1 DOCUMENTS.DOCUMENT_ID%TYPE;
    P2 DOCUMENTS.DOCUMENT_NAME%TYPE;
    P3 DOCUMENTS.DOCUMENT_DESCRIPTION%TYPE;
    P4 DOCUMENTS.RECORD_TIMESTAMP%TYPE;
    P5 DOCUMENTS.TIMESTAMP%TYPE;
    P6 DOCUMENTS.RECORD_USER_ID%TYPE;
    P7 DOCUMENTS.USER_ID%TYPE;
	-- using pragma to independent commit only this procedure
	PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
    DOC_FILE := UTL_FILE.FOPEN(directory_name,csv_file,'R');
        LOOP
            UTL_FILE.GET_LINE(DOC_FILE,LINIA);
            dbms_output.put_line(LINIA);
            P1 := REGEXP_SUBSTR(LINIA,'[^;]+');
            dbms_output.put_line(P1);
            P2 := REGEXP_SUBSTR(LINIA,'[^;]+',1,2);
            dbms_output.put_line(P2);
            P3 := REGEXP_SUBSTR(LINIA,'[^;]+',1,3);
            dbms_output.put_line(P3);
            P4 := to_timestamp(REGEXP_SUBSTR(LINIA,'[^;]+',1,4), 'RR/MM/DD HH24:MI:SS.FF');
            dbms_output.put_line(P4);
            P5 := to_timestamp(REGEXP_SUBSTR(LINIA,'[^;]+',1,5), 'RR/MM/DD HH24:MI:SS.FF');
            dbms_output.put_line(P5);
            P6 := REGEXP_SUBSTR(LINIA,'[^;]+',1,6);
            dbms_output.put_line(P6);
            P7 := REGEXP_SUBSTR(LINIA,'[^;]+',1,7);
            dbms_output.put_line(P7);
            INSERT INTO DOCUMENTS VALUES(P1,P2,P3,P4,P5,P6,P7);
        END LOOP;
EXCEPTION
    WHEN NO_DATA_FOUND THEN UTL_FILE.FCLOSE(DOC_FILE);
	COMMIT; -- commit all data inserted to a table
END;
/

/*inserting example data*/

INSERT INTO documents 
		(document_name, record_timestamp, timestamp, record_user_id,user_id)
VALUES  ('Doc_no_1', systimestamp, systimestamp, user, user);

INSERT INTO documents 
		(document_name, record_timestamp, timestamp, record_user_id,user_id)
VALUES  ('Doc_no_2', systimestamp, systimestamp, user, user);

INSERT INTO documents 
		(document_name, document_description, record_timestamp, timestamp, record_user_id,user_id)
VALUES  ('Doc_no_3','Description doc no. 3' ,systimestamp, systimestamp, user, user);

INSERT INTO documents 
		(document_name, document_description, record_timestamp, timestamp, record_user_id,user_id)
VALUES  ('Doc_no_4','Description doc no. 4' ,systimestamp, systimestamp, user, user);

COMMIT;

spool off;