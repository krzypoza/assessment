Before start skrypt:
1. You should create folder in Windows system and directory in database. 
2. user must have privilege to this directory and to package utl_file.

In task 4 parameters for procedure are directory name and csv file name
Log file will be create on your desktop.